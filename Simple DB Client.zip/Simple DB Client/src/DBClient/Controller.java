package DBClient;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.util.Callback;

import java.sql.*;


public class Controller {


    @FXML
    private TextArea query;

    @FXML
    private TableView output;

    //Database Access
    public static void DBTest(String query){



    }

    public void results (Event evt){
        //use observable lists
        //Take the query
        String command = String.valueOf(query.getText());

        //Generate database access
        String conn_url = "jdbc:mysql://localhost:3306/mysql"; //employees?user=root&password=&serverTimezone=UTC";
        Connection conn = null;

        //Preset Parametsr
        int row_num=0;
        int col_num=0;
        //Insert Query
        try {
            conn = DriverManager.getConnection(conn_url);
            PreparedStatement stmt = conn.prepareStatement(command);
            ResultSet rs = stmt.executeQuery();

            //Get size of row length
            rs.last();
            row_num=rs.getRow();
            rs.first(); //Returns cursors to the first row
            //Get number of columns
            ResultSetMetaData rsmd=rs.getMetaData();
            col_num=rsmd.getColumnCount();


            //Put text into the columns
            for (int i = 0; i<col_num;i++){
                final int j=i;
                String name = rsmd.getColumnName(i+1);
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                output.getColumns().addAll(col);

            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }












    }
}
