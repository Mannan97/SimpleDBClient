module Simple.DB.Client {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;

    opens DBClient;
}